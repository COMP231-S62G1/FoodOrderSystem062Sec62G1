<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <title>Centennial College Food Order</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <link href="../styles.css" rel="stylesheet" type="text/css" media="screen" />
    <style type="text/css">
    .auto-style2 {
        text-align: left;
    }
    .auto-style3 {
        text-align: right;
    }
    .auto-style4 {
        margin-left: 0px;
    }
    </style>
    

</head>
<body>

<div id="content">
	<div id="back_all">
<!-- header begins -->
<div id="header">
  <div id="menu">
		<ul>
			<li><a href=""  title=""></a></li>
			<li><a href="" title=""></a></li>
			<li><a href="" title="">Home</a></li>
			<li><a href=""  title="">View Order</a></li>
			<li><a href="" title="">Log Out</a></li>
			<li><a href="" title="">Contact</a></li>
		</ul>
	</div>
	<div id="logo">
		<h1><a href="http://www.centennialcollege.ca" title="Centennial College Food Order">Centennial College Food Order</a></h1>
		<h2><a href="http://github.com/COMP231-S62G1/FoodOrderSystem062Sec62G1/" id="metamorph">Design by Group 1</a></h2>
	</div>
</div>
<!-- header ends -->